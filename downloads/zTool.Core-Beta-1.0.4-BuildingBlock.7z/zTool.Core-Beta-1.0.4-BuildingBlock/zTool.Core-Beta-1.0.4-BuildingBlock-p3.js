﻿//==============================================================================================================================================
//*********************************************************第三部分，HTML属性操作***************************************************************
//该部分主要围绕操作HTML节点的一些属性，比如css,attribute
//也包括一些浏览器的属性
//该部分包含:
//1.获得浏览器可见区域大小的对象
//2.某对象的绝对宽度
//3.某对象的绝对高度
//4.滚动条已滚去的宽度
//5.滚动条已滚去的高度
//6.传入浏览器类型，验证是否为真(true/fales)
//7.获取当前浏览器类型
//8.传入元素对象，获得元素的静态/动态 LEFT/TOP
//9.获取css/设置css/删除css
//10.判断是否是特殊的CSS名称
//11.获取特殊的CSS值
//12.设置特殊的CSS值
//13.删除特殊的CSS值
//14.css名称变js的CSS名称格式
//15.获取attribute或设置attribute
//16.移除attribute
//17.获得value
//18.建立获取纯CSS样式的方法
//:2013-06-10
//==============================================================================================================================================

//获得浏览器可见区域大小的对象
zT.bodySize = {
    height: function () {
        return parseInt(document.documentElement.clientHeight || document.body.offsetHeight);
    }
,
    width: function () {
        return parseInt(document.documentElement.clientWidth || document.body.offsetWidth);
    }
} //某对象的绝对宽度
zT.width = function () {
    return this.lObj[0].clientWidth || this.lObj[0].offsetWidth;
} //某对象的绝对高度
zT.height = function () {
    return this.lObj[0].clientHeight || this.lObj[0].offsetHeight;
} //滚动条已滚去的宽度
zT.scrollLeft = function () {
    return this.lObj[0].scrollLeft || this.lObj[0].scrollLeft;
} //滚动条已滚去的高度
zT.scrollTop = function () {
    return this.lObj[0].scrollTop || this.lObj[0].scrollTop;
} //传入浏览器类型，验证是否为真(true/fales)
//浏览器类型字典：chrome，opera，msie，safari，firefox，gecko
zT.bor = function (b) {
    if (!b) { return this.Borwser(); }
    if (this.Borwser().indexOf(b) != -1) {
        return true;
    }
    return false;
} //获取当前浏览器类型
zT.Borwser = function () {
    var ua = navigator.userAgent.toLowerCase();
    if (ua == null) return "ie";
    else if (ua.indexOf('chrome') != -1) return "chrome";
    else if (ua.indexOf('opera') != -1) return "opera";
    else if (ua.indexOf('safari') != -1) return "safari";
    else if (ua.indexOf('firefox') != -1) return "firefox";
    else if (ua.indexOf('gecko') != -1) return "gecko";
    else if (ua.indexOf('msie 6.0') != -1) return "msie 6.0";
    else if (ua.indexOf('msie 7.0') != -1) return "msie 7.0";
    else if (ua.indexOf('msie 8.0') != -1) return "msie 8.0";
    else if (ua.indexOf('msie 9.0') != -1) return "msie 9.0";
    else if (ua.indexOf('msie') != -1) return "msie";
    else return "ie";
} //传入元素对象，获得元素的静态/动态 LEFT/TOP
//返回json:{x:INT,y:INT}
zT.position = function () {//2
    if (this.lObj.length == 0) { return undefined };
    var ua = navigator.userAgent.toLowerCase();
    var isOpera = (ua.indexOf('opera') != -1);
    var isIE = (ua.indexOf('msie') != -1 && !isOpera); // not opera spoof
    var el = this.lObj[0];

    if (el.parentNode === null || el.style.display == 'none') {
        return null;
    }


    var parent = null;
    var pos = [];
    var box;

    if (el.getBoundingClientRect)    //IE
    {
        box = el.getBoundingClientRect();
        var scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
        var scrollLeft = Math.max(document.documentElement.scrollLeft, document.body.scrollLeft);
        return { x: box.left + scrollLeft, y: box.top + scrollTop };
    }
    else if (document.getBoxObjectFor)    // gecko    
    {
        box = document.getBoxObjectFor(el);
        var borderLeft = (el.style.borderLeftWidth) ? parseInt(el.style.borderLeftWidth) : 0;
        var borderTop = (el.style.borderTopWidth) ? parseInt(el.style.borderTopWidth) : 0;
        pos = [box.x - borderLeft, box.y - borderTop];
    }
    else    // safari & opera    
    {
        pos = [el.offsetLeft, el.offsetTop];
        parent = el.offsetParent;

        if (parent != el) {
            while (parent) {
                pos[0] += parent.offsetLeft;
                pos[1] += parent.offsetTop;
                parent = parent.offsetParent;
            }
        }

        if (ua.indexOf('opera') != -1 || (ua.indexOf('safari') != -1 && el.style.position == 'absolute')) {
            pos[0] -= document.body.offsetLeft;
            pos[1] -= document.body.offsetTop;
        }
    }

    if (el.parentNode) {
        parent = el.parentNode;
    }
    else {
        parent = null;
    }

    while (parent && parent.tagName != 'BODY' && parent.tagName != 'HTML') { // account for any scrolled ancestors
        pos[0] -= parent.scrollLeft;
        pos[1] -= parent.scrollTop;

        if (parent.parentNode) {
            parent = parent.parentNode;
        }
        else {
            parent = null;
        }
    }

    return { x: pos[0], y: pos[1] };

}
//获取css/设置css/删除css
//display:block导致table等元素混乱的注释请参看第587行
zT.css = function (cssName, cssValue) {
    if (this.lObj.length == 0) { return undefined };
    var speCss = zZ.fn.ifIsSpecialCssName(cssName);

    //如果只是获取STYLE属性
    if (!cssValue && cssValue != '') {

        if (speCss) { return this.getSpecialCssValue(cssName) };
        var resultValue = zZ.Zstatic.clCss(this.lObj[0], this.cssNameToJavascript(cssName));

        //记录日期 ： 2013-02-26
        //如果是auto就是用其他的获取手段
        //AUTO现象通常出现在IE6/7/8上，已知HEIGHT/和WIDTH会出现此现象
        //将来可能要单独写个方法处理此问题
        if (resultValue == 'auto') {
            switch (cssName) {
                case "height":
                    resultValue = (this.lObj[0].clientHeight || this.lObj[0].offsetHeight) + "px";
                    break;
                case "width":
                    resultValue = (this.lObj[0].clientWidth || this.lObj[0].offsetWidth) + "px";
                    break;
                default:
                    resultValue = 0;
                    break;
            }
        }
        return resultValue;
    }

    //如果要修改/或者添加CSS属性
    if (cssValue && cssName) {
        for (var j = 0; j < this.lObj.length; j++) {
            if (cssValue == 'remove' && speCss) { this.removeSpecialCssValue(cssName, this.lObj[j]); continue; }
            if (speCss) {
                this.setSpecialCssValue(cssName, cssValue, this.lObj[j]);
                continue;
            }

            var changedCss = '',
            //获得行样式
                lineStyle = this.bor('msie') ? this.lObj[j].style.cssText : this.lObj[j].getAttribute('style');

            //如果行样式存在的话，就直接替换行样式
            if (lineStyle) {
                var styleList = lineStyle.toString().split(';');
                for (var i = 0; i < styleList.length; i++) {
                    //除了要设置的属性外 其他的照旧
                    if (this.trim(styleList[i].toString().split(':')[0]).toLowerCase() != this.trim(cssName).toLowerCase() && styleList[i] != '') {
                        changedCss += styleList[i] + ';';
                    }
                }
                //最后加上要改变的样式
                if (cssValue != 'remove') {
                    changedCss += cssName + ':' + cssValue + ';';
                }
                if (changedCss == '') { this.lObj[j].removeAttribute('style'); }
                if (this.bor('msie')) {
                    this.lObj[j].style.cssText = changedCss;
                } else {
                    this.lObj[j].setAttribute('style', changedCss);
                }
            } else {
                if (cssValue != 'remove') {
                    changedCss = cssName + ':' + cssValue + ';';
                }
                if (this.bor('msie')) {
                    this.lObj[j].style.cssText = changedCss;
                } else {
                    this.lObj[j].setAttribute('style', changedCss);
                }
            }
        }
        return this;
    }
}
//判断是否是特殊的CSS名称
zT.ifIsSpecialCssName = function (cssName) {
    //修复透明问题，由于上次优化代码导致判断错误出现在IE6下无法透明
    //已将BUG修复 2013-04-10
    if (cssName == 'opacity') {
        if (zZ.fn.bor('msie 6.0') || zZ.fn.bor('msie 7.0') || zZ.fn.bor('msie 8.0')) {
            return true;
        }
    }
    if (cssName == 'blur') {
        if (zZ.fn.bor('chrome') || zZ.fn.bor('safari') || zZ.fn.bor('opera')) {
            return true;
        }
    }
    return false;
}
//获取特殊的CSS值
zT.getSpecialCssValue = function (cssName, Obj) {
    if (cssName == 'opacity') {
        if (this.lObj[0].filters.alpha) {
            return parseInt(this.lObj[0].filters.alpha.opacity) / 100;
        }

        if (this.lObj[0].style.filter) {
            return (parseInt(this.lObj[0].style.filter.replace('alpha(opacity = ', '').replace(')', '')) / 100).toString();
        }
        return 100;
    }

    if (cssName == 'blur') {
        if (zZ.fn.bor('chrome') || zZ.fn.bor('safari') || zZ.fn.bor('opera')) {
            if (zZ.Zstatic.clCss(this.lObj[0], this.cssNameToJavascript('webkit-filter'))) {
                var value = zZ.Zstatic.clCss(this.lObj[0], this.cssNameToJavascript('webkit-filter'));
                return value.replace('blur(', '').replace(')', '');
            }
            return '0px';
        }
    }
}
//设置特殊的CSS值
zT.setSpecialCssValue = function (cssName, cssValue, Obj) {
    if (cssName == 'opacity') {
        Obj.style.filter = 'alpha(opacity=' + cssValue * 100 + ')';
    }

    if (cssName == 'blur') {
        if (zZ.fn.bor('chrome') || zZ.fn.bor('safari') || zZ.fn.bor('opera')) {
            zTool(Obj).css('-webkit-filter', 'blur(' + cssValue + ')').css('-o-filter', 'blur(' + cssValue + ')')
        }
    }
}
//删除特殊的CSS值
zT.removeSpecialCssValue = function (cssName, Obj) {
    if (cssName == 'opacity') {
        Obj.style.filter = "";
    }

    if (cssName == 'blur') {
        if (zZ.fn.bor('chrome') || zZ.fn.bor('safari') || zZ.fn.bor('opera')) {
            zTool(Obj).css('-webkit-filter', 'remove').css('-o-filter', 'remove')
        }
    }
}
//css名称变js的CSS名称格式
zT.cssNameToJavascript = function (name) {
    if (name.indexOf('-') != '-1') {
        var namearr = name.split('-');
        return namearr[0] + namearr[1].substring(0, 1).toUpperCase() + namearr[1].substring(1, namearr[1].length);
    }
    return name;
} //获取attribute或设置attribute
zT.attr = function (attrName, attrValue) {
    if (this.lObj.length == 0) { return undefined };
    //如果attrvalue存在 说明需要设置属性
    if (attrValue && attrValue) {
        for (var j = 0; j < this.lObj.length; j++) {
            if (attrName == 'class' && (this.bor('msie 6.0') || this.bor('msie 7.0') || this.bor('msie 8.0'))) { this.lObj[j].setAttribute('className', attrValue); }
            else if (attrName == 'style' && this.bor('msie')) { this.lObj[j].style.cssText = attrValue; }
            else { this.lObj[j].setAttribute(attrName, attrValue); }
        }
        return this;
    } else { //否则就是获取
        if (attrName == 'class' && (this.bor('msie 6.0') || this.bor('msie 7.0') || this.bor('msie 8.0'))) { return this.lObj[0].getAttribute('className') || this.lObj[0].getAttribute('class'); }
        if (attrName == 'style' && this.bor('msie')) { return this.lObj[0].style.cssText; }
        return this.lObj[0].getAttribute(attrName);
    }
} //移除attribute
zT.removeAttr = function (attrName) {
    for (var j = 0; j < this.lObj.length; j++) {
        if (attrName == 'class' && (this.bor('msie 6.0') || this.bor('msie 7.0') || this.bor('msie 8.0'))) { this.lObj[j].removeAttribute('className'); }
        this.lObj[j].removeAttribute(attrName);
    }
    return this;
} //获得value
zT.val = function (value) {
    if (this.lObj.length == 0) { return undefined };
    if (value == undefined || value == null) {
        return this.lObj[0].value;
    } else {
        for (var j = 0; j < this.lObj.length; j++) {
            this.lObj[j].value = value;
        }
    }
    return this;
}
//此处为建立获取纯CSS样式的方法
//非IE
if (!zZ.fn.bor('msie 6.0') && !zZ.fn.bor('msie 7.0') && !zZ.fn.bor('msie 8.0')) {
    //传入对象/JS格式的STYLE名称，返回属性值
    zZ.Zstatic.clCss = function (obj, cssName) {
        return window.getComputedStyle(obj, null)[cssName];
    }
}
//IE
else {
    zZ.Zstatic.clCss = function (obj, cssName) {
        //修正参数错误 : 2013年2月26日
        switch (cssName) {
            case "borderBottom":
                cssName = "borderBottomWidth";
                break;
            case "borderTop":
                cssName = "borderTopWidth";
                break;
            case "borderLeft":
                cssName = "borderLeftWidth";
                break;
            case "borderRight":
                cssName = "borderRightWidth";
                break;
        }
        return obj.currentStyle[cssName];
    }
}