﻿//==============================================================================================================================================
//*********************************************************第四部分，事件操作*******************************************************************
//该部分包含事件的绑定/取消/快速绑定方法
//1.绑定事件的方法
//2.绑定事件的内部方法
//3.取消事件的方法
//4.判断是否为function的方法
//5.各种事件的快速绑定
//6.事件闭包
//:2013-06-10
//==============================================================================================================================================

//绑定事件,参考资料如下：
//参考资料来自：http://www.jb51.net/article/18220.htm
//Mozilla中： 
//addEventListener的使用方式： 
//target.addEventListener(type, listener, useCapture); 
//target： 文档节点、document、window 或 XMLHttpRequest。 
//type： 字符串，事件名称，不含“on”，比如“click”、“mouseover”、“keydown”等。 
//listener ：实现了 EventListener 接口或者是 JavaScript 中的函数。 
//useCapture ：是否使用捕捉，一般用 false 。例如：document.getElementById("testText").addEventListener("keydown", function (event) { alert(event.keyCode); }, false); 
//IE中：
//target.attachEvent(type, listener); 
//target： 文档节点、document、window 或 XMLHttpRequest。 
//type： 字符串，事件名称，含“on”，比如“onclick”、“onmouseover”、“onkeydown”等。 
//listener ：实现了 EventListener 接口或者是 JavaScript 中的函数。 例如：document.getElementById("txt").attachEvent("onclick",function(event){alert(event.keyCode);}); 
//W3C 及 IE 同时支持移除指定的事件, 用途是移除设定的事件, 格式分别如下: 
//W3C格式: 
//removeEventListener(event,function,capture/bubble); 
//Windows IE的格式如下: 
//detachEvent(event,function); 
//target.addEventListener(type, listener, useCapture); 
//target 文档节点、document、window 或 XMLHttpRequest。 
//type 字符串，事件名称，不含“on”，比如“click”、“mouseover”、“keydown”等。 
//listener 实现了 EventListener 接口或者是 JavaScript 中的函数。 
//useCapture 是否使用捕捉，看了后面的事件流一节后就明白了，一般用 false
zT.bind = function (event, callBack) {
    if (this.lObj.length == 0) { return undefined; }
    for (var i = 0; i < this.lObj.length; i++) {

        //先注销其所有事件
        this.unInsEvent(event, this.lObj[i]);

        //如果没有事件集合，就给它事件集合
        if (!this.lObj[i]['zEvent-club']) {
            this.lObj[i]['zEvent-club'] = {};
        }

        //如果没有特定事件，就给它特定事件
        if (!this.lObj[i]['zEvent-club'][event]) {
            this.lObj[i]['zEvent-club'][event] = { arr: [], fFunc: null };
        }

        //将事件单元压入栈
        this.lObj[i]['zEvent-club'][event]['arr'].push(callBack);

        //然后在对象上绑定所有事件
        this.evalEvent(this.lObj[i], event, false);
    }

    return this;
}   //绑定事件
zT.evalEvent = function (thisObj, event, useCapture) {
    //生成事件委托
    var action = new zZ.eventFunction(thisObj, thisObj['zEvent-club'][event]['arr']);
    //将最后绑定的方法的样子保存
    thisObj['zEvent-club'][event]['fFunc'] = action.callFunction;

    //判断浏览器
    //如果是IE浏览器就使用IE特有的事件绑定机制
    if (thisObj.attachEvent) {
        var eventString = 'on' + event;
        thisObj.attachEvent(eventString, action.callFunction);
    } else {
        //否则就使用标准语法绑定
        thisObj.addEventListener(event, action.callFunction, useCapture || false);
    }
} //卸载事件
zT.unInsEvent = function (event, thisObj) {
    if (!thisObj['zEvent-club']) { return; }
    if (!thisObj['zEvent-club'][event]) { return; }
    //获得事件函数
    var action = thisObj['zEvent-club'][event]['fFunc'];
    this.removeEvent(thisObj, action, event);
}
//移除事件
zT.removeEvent = function (thisObj, action, event) {
    //判断浏览器
    //如果是IE浏览器就是用IE特有的事件绑定机制
    if (thisObj.detachEvent) {
        var eventString = 'on' + event;
        thisObj.detachEvent(eventString, action);
    } else {
        thisObj.removeEventListener(event, action, false);
    }
}

////取消事件绑定
zT.unbind = function (event, func) {
    if (this.lObj.length == 0) { return undefined; }
    for (var i = 0; i < this.lObj.length; i++) {
        //先用传统的方式删除一下，避免漏掉本来就绑定在上面的事件
        if (func) { this.removeEvent(this.lObj[i], func, event); }
        //再判断用 zTool动态绑定的事件
        if (!this.lObj[i]['zEvent-club']) { return; }
        if (!this.lObj[i]['zEvent-club'][event]) { return; }
        //如果func存在，说明使用者想撤销的是单个事件
        if (func && this.lObj[i]['zEvent-club'][event]['arr'].length > 1) {
            //撤销在元素上真实绑定的所有事件先
            this.unInsEvent(event, this.lObj[i]);
            //在本元素的事件堆里寻找要撤销的事件
            for (var j = 0; j < this.lObj[i]['zEvent-club'][event]['arr'].length; j++) {
                if (this.lObj[i]['zEvent-club'][event]['arr'][j] == func) {
                    delete this.lObj[i]['zEvent-club'][event]['arr'][j];
                }
            }
            //整理一下其中的空元素
            this.lObj[i]['zEvent-club'][event]['arr'] = zZ.fn.clearEmptyItem(this.lObj[i]['zEvent-club'][event]['arr']);

            //然后在对象上绑定剩下的事件
            this.evalEvent(this.lObj[i], event, false);
        } else { //否则就是撤销所有事件
            this.unInsEvent(event, this.lObj[i]);
            //撤销该元素上事件集合中的特定事件
            this.lObj[i]['zEvent-club'][event] = undefined;
        }

    }
    return this;
}
//除去zT.ready 方法之外，以下一些方法如果在开发中认为多余，可以剔除
//可以剔除的方法如下：
//zT.click，zT.dblclick，zT.blur ，zT.focus，zT.keydown，zT.keypress，zT.keyup，zT.mousedown，zT.mousemove
//zT.mouseout，zT.mouseover，zT.mouseup，zT.change，zT.scroll，zT.load，zT.resize
//：2013-06-10
zT.click = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) {
        for (var i in this.lObj) {
            this.lObj[i].click();
        } return;
    }
    this.bind('click', callBack);
}
zT.dblclick = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].dblclick(); } return; }
    this.bind('dblclick', callBack);
}
zT.blur = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].blur(); } return; }
    this.bind('blur', callBack);
}
zT.focus = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].focus(); } return; }
    this.bind('focus', callBack);
}
zT.keydown = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].keydown(); } return; }
    this.bind('keydown', callBack);
}
zT.keypress = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].keypress(); } return; }
    this.bind('keypress', callBack);
}
zT.keyup = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].keyup(); } return; }
    this.bind('keyup', callBack);
}
zT.mousedown = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].mousedown(); } return; }
    this.bind('mousedown', callBack);
}
zT.mousemove = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].mousemove(); } return; }
    this.bind('mousemove', callBack);
}
zT.mouseout = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].mouseout(); } return; }
    this.bind('mouseout', callBack);
}
zT.mouseover = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].mouseover(); } return; }
    this.bind('mouseover', callBack);
}
zT.mouseup = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].mouseup(); } return; }
    this.bind('mouseup', callBack);
}
zT.change = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].change(); } return; }
    this.bind('change', callBack);
}
zT.scroll = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].scroll(); } return; }
    this.bind('scroll', callBack);
}
zT.load = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].load(); } return; }
    this.bind('load', callBack);
}
zT.resize = function (callBack) {
    if (!zZ.fn.isFunction(callBack)) { for (var i in this.lObj) { this.lObj[i].resize(); } return; }
    this.bind('resize', callBack);
}
zT.ready = function (callBack) {
    //2013-08-13:
    //如果方法是在页面加载后执行的，就直接执行回调函数
    if (document.readyState == "complete") {
        callBack();
        return this;
    }
    this.bind('readystatechange', function () {
        if (this.readyState == "complete") {
            callBack();
        }
    });
}     //检查对象是否为方法
zT.isFunction = function (o) {
    if (typeof (o) == 'function') { return true; }
    return false;
} //事件闭包
zZ.eventFunction = function (thisObj, callBackArr) {
    this.callFunction = function () {
        for (var i = 0; i < callBackArr.length; i++) {
            callBackArr[i].apply(thisObj, arguments);
        }
    }
}