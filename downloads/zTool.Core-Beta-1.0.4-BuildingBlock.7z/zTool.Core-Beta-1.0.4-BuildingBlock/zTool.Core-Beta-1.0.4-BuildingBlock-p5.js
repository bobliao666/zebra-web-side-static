﻿//////////////////////////////////////////////////////////////////富功能////////////////////////////////////////////////////////////////////////
//富功能包含 动画效果模块，Ajax通讯模块，工具模块（杂项功能）



//==============================================================================================================================================
//*********************************************************第一部分，动画操作*******************************************************************
//该部分实现动画效果，动画列队等效果
//1.动画的实现方法
//2.停止动画的方法
//3.显示
//4.隐藏
//5.缓动效果类
//6.每一帧执行的动作
//7.帧对象的获取方法
//8.系统的帧对象
//:2013-06-10
//==============================================================================================================================================

//动画的实现方法，传入设置，时间,回调函数，运行时回调函数（每运行一个周期回调一次）
//效果：默认不填写为Linear, 参数分别为'--'(Linear),'-<'(easeIn),'>-'(easeOut),'<>'(easeInOut)
//ops格式为['属性(可为zNum.名称)','结束数值','单位','效果','开始数值(可不填写)']
//属性为zNum 并且填写开始数值，不填写单位的话，说明这是数值动画，可以在一些复杂的
//css滤镜或者属性中用到，详情参考api
zT.animation = function (ops, time, callBack, rCallback) {
    if (this.lObj.length == 0) { return undefined };
    for (var j = 0; j < this.lObj.length; j++) {
        //在此处获得属性的开始数值
        var options = [];

        //产生动画ID
        var aid = (+new Date / Math.random()).toString().replace('.', '');


        //填充开始数值
        for (var i = 0; i < ops.length; i++) {
            //options格式为['属性','开始数值','结束数值','单位','效果']
            options.push([ops[i][0], ops[i][4] || '-', ops[i][1], ops[i][2] || '', ops[i][3] || '']);
        }

        //每一帧执行计算的方法
        var action = zZ.Zstatic.frameAction,
        //推送动画到播放列表*填写参数
                animationSingal = { 'lpoolID': aid,
                    'lpoolObj': this.lObj[j],
                    'startTime': '-',
                    'TotalTime': time,
                    'options': options,
                    'state': 'play',
                    'action': action,
                    'callBack': callBack || null,
                    'runtimeCallback': rCallback || null
                };
        //推送!
        zZ.Zstatic.intervalList.push(animationSingal);
    }
} //停止动画的方法
zT.stopAnimation = function () {
    //先关闭动画计时器
    clearInterval(zZ.Zstatic.fxFrame);
    zZ.Zstatic.fxFrame = null;
    //删除动画精灵
    for (var j = 0; j < this.lObj.length; j++) {
        if (this.lObj[j].getAttribute('_jpool_animation_id')) {
            for (var i = 0; i < zZ.Zstatic.intervalList.length; i++) {
                if (zZ.Zstatic.intervalList[i]) {
                    //停止该对象上所有的动画而不是某个动画，所以是对比对象是否一致而不是动画id
                    if (zZ.Zstatic.intervalList[i].lpoolObj == this.lObj[j]) {
                        delete zZ.Zstatic.intervalList[i];
                    }
                }
            }
            this.lObj[j].removeAttribute('_jpool_animation_id');
        }
    }
    //清除一下无效数组:2013-06-17
    zZ.Zstatic.intervalList = zZ.fn.clearEmptyItem(zZ.Zstatic.intervalList);
    //再恢复帧对象运行
    zZ.Zstatic.fxFrame = zZ.Zstatic.fxFrameFunction();
} //显示
zT.show = function (p, callback) {
    if (this.lObj.length == 0) { return undefined; }
    if (!callback) { callback = function () { } }
    var callBackSwitch = 0;
    for (var j = 0; j < this.lObj.length; j++) {
        if (zZ(this.lObj[j]).css('display') == 'block') { callBackSwitch++; continue; }
        if (p) {

            var heightcss = '', opacitycss = '', overflowcss = '';

            if (zZ(this.lObj[j]).css('height')) {
                heightcss = zZ(this.lObj[j]).css('height');
            }

            if (zZ(this.lObj[j]).css('opacity')) {
                opacitycss = zZ(this.lObj[j]).css('opacity');
            }

            if (zZ(this.lObj[j]).css('overflow')) {
                overflowcss = zZ(this.lObj[j]).css('overflow');
            }

            //如果不是IE6或者ie7就按照W3C标准赋予DISPLAY值，如果不这么做则无法正确显示元素 ：2013-02-26
            //该问题已经调查，调查结果如下：2013-05-22
            ////在页面顶部，HTML类型标签为<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd"> 时，
            ////视为HTML 4.01页面模式，在该模式下需要严谨定义CSS中的DISPLAY值于对象，否则在遵从W3C HTML 4.01的浏览器中，某些元素如‘table’会发生混乱
            ////该问题解决办法有两种，分别如下
            ////////1.将页面顶部的<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">标签更换为<!DOCTYPE html>可以正常使用display:block来表示元素显示
            ////////2.不改变W3C的DOCTYPE标准的支持下，判断元素的类型，给予元素正确的渲染方法
            ////为解决此问题，本人采用了第二种解决方法
            ////然后为保证此问题能够得到完美解决，决定过段时间编写一个处理函数，判断页面支持类型，相应处理。
            if (!zZ.fn.bor('msie 7.0') && !zZ.fn.bor('msie 6.0')) {
                switch (this.lObj[j].tagName.toLowerCase()) {
                    case 'table':
                        zZ(this.lObj[j]).css('display', 'table');
                        break;
                    case 'tbody':
                        zZ(this.lObj[j]).css('display', 'table-row-group');
                        break;
                    case 'tr':
                        zZ(this.lObj[j]).css('display', 'table-row');
                        break;
                    case 'td':
                        zZ(this.lObj[j]).css('display', 'table-cell');
                        break;
                    case 'th':
                        zZ(this.lObj[j]).css('display', 'table-cell');
                        break;
                    case 'thead':
                        zZ(this.lObj[j]).css('display', 'table-header-group');
                        break;
                    case 'tfoot':
                        zZ(this.lObj[j]).css('display', 'table-footer-group');
                        break;
                    default:
                        zZ(this.lObj[j]).css('display', 'block');
                        break;
                }
            } else {
                zZ(this.lObj[j]).css('display', 'block');
            }

            var height = zZ(this.lObj[j]).height();
            zZ(this.lObj[j]).css('height', '0px').css('opacity', '0').css('overflow', 'hidden');
            zZ(this.lObj[j]).animation([['height', height, 'px', '>-'], ['opacity', 1, '', '>-']], p, function () {
                if (heightcss && !'auto') {
                    zZ(this).css('height', heightcss + 'px');
                } else { zZ(this).css('height', 'remove'); }

                if (opacitycss && !'auto') {
                    zZ(this).css('opacity', opacitycss);
                } else { zZ(this).css('opacity', 'remove'); }

                if (overflowcss && !'auto') {
                    zZ(this).css('overflow', overflowcss);
                } else { zZ(this).css('overflow', 'remove'); }
                callback.apply(this, arguments);
            });
        }
        else {
            //如果不是IE6或者ie7就按照W3C标准赋予DISPLAY值 ：2013-02-26
            //详细说明参看第1221行
            if (!zZ.fn.bor('msie 7.0') && !zZ.fn.bor('msie 6.0')) {
                switch (this.lObj[j].tagName.toLowerCase()) {
                    case 'table':
                        zZ(this.lObj[j]).css('display', 'table');
                        break;
                    case 'tbody':
                        zZ(this.lObj[j]).css('display', 'table-row-group');
                        break;
                    case 'tr':
                        zZ(this.lObj[j]).css('display', 'table-row');
                        break;
                    case 'td':
                        zZ(this.lObj[j]).css('display', 'table-cell');
                        break;
                    case 'th':
                        zZ(this.lObj[j]).css('display', 'table-cell');
                        break;
                    case 'thead':
                        zZ(this.lObj[j]).css('display', 'table-header-group');
                        break;
                    case 'tfoot':
                        zZ(this.lObj[j]).css('display', 'table-footer-group');
                        break;
                    default:
                        zZ(this.lObj[j]).css('display', 'block');
                        break;
                }
                return this;
            } else {
                zZ(this.lObj[j]).css('display', 'block');
                return this;
            }
        }
    }
    if (callBackSwitch == this.lObj.length) {
        callback.apply(this, arguments);
        return this;
    }
}    //隐藏
zT.hide = function (p, callback) {
    if (this.lObj.length == 0) { return undefined; }
    if (!callback) { callback = function () { } }
    var callBackSwitch = 0;
    for (var j = 0; j < this.lObj.length; j++) {
        if (zZ(this.lObj[j]).css('display') == 'none') { callBackSwitch++; continue; }
        if (p) {

            var heightcss = '', opacitycss = '', overflowcss = '';

            if (zZ(this.lObj[j]).css('height')) {
                heightcss = zZ(this.lObj[j]).css('height');
            }

            if (zZ(this.lObj[j]).css('opacity')) {
                opacitycss = zZ(this.lObj[j]).css('opacity');
            }

            if (zZ(this.lObj[j]).css('overflow')) {
                overflowcss = zZ(this.lObj[j]).css('overflow');
            }

            var height = zZ(this.lObj[j]).height();
            zZ(this.lObj[j]).css('height', height + "px").css('opacity', '1').css('overflow', 'hidden');
            zZ(this.lObj[j]).animation([['height', 0, 'px', '>-'], ['opacity', 0, '', '>-']], p, function () {
                zZ(this).css('display', 'none');

                if (heightcss && !'auto') {
                    zZ(this).css('height', heightcss + 'px');
                } else { zZ(this).css('height', 'remove'); }

                if (opacitycss && !'auto') {
                    zZ(this).css('opacity', opacitycss);
                } else { zZ(this).css('opacity', 'remove'); }

                if (overflowcss && !'auto') {
                    zZ(this).css('overflow', overflowcss);
                } else { zZ(this).css('overflow', 'remove'); }

                callback.apply(this, arguments);
            });
        } else {
            zZ(this.lObj[j]).css('display', 'none');
            return this;
        }
    }

    if (callBackSwitch == this.lObj.length) {
        callback.apply(this, arguments);
        return this;
    }
}

//****缓动效果类****
//****算法来自 http://www.cnblogs.com/cloudgamer/archive/2009/01/06/Tween.html ****
//****cloudgamer编写****
//****廖力节选****
//d：  duration（持续步长）。
//c：  change in value（变化增量）；
//b：  beginning value（位置初始值）；
//t：  current time（当前步长）；
zZ.Tween = {
    //无缓动效果
    Linear: function (t, b, c, d) { return c * t / d + b; },
    //五次方的缓动
    Quint: {
        easeIn: function (t, b, c, d) {
            return c * (t /= d) * t * t * t * t + b;
        },
        easeOut: function (t, b, c, d) {
            return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
        },
        easeInOut: function (t, b, c, d) {
            if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
            return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
        }
    }
,
    Bounce: {
        easeOut: function (t, b, c, d) {
            if ((t /= d) < (1 / 2.75)) {
                return c * (7.5625 * t * t) + b;
            } else if (t < (2 / 2.75)) {
                return c * (7.5625 * (t -= (1.5 / 2.75)) * t + .75) + b;
            } else if (t < (2.5 / 2.75)) {
                return c * (7.5625 * (t -= (2.25 / 2.75)) * t + .9375) + b;
            } else {
                return c * (7.5625 * (t -= (2.625 / 2.75)) * t + .984375) + b;
            }
        }
    }
}

//每一帧执行的动作
zZ.Zstatic.frameAction = function (ft, as) {
    if (!zZ(as.lpoolObj).attr('_jpool_animation_id')) { zZ(as.lpoolObj).attr('_jpool_animation_id', as.lpoolID); }
    if (zZ(as.lpoolObj).attr('_jpool_animation_id') == as.lpoolID) {

        //执行计算
        var startTime, endTime, totalTime;

        if (as.startTime == '-') {
            as.startTime = parseInt(+new Date);
        }

        //开始时间
        startTime = as.startTime;

        //结束时间
        endTime = as.startTime + as.TotalTime;

        //总时间
        totalTime = as.TotalTime;

        //参数
        options = as.options;

        //计算参数
        for (var i = 0; i < options.length; i++) {

            //在此处获取该属性的初始值
            //获取一次后不需要再度获取
            //['属性','开始数值','结束数值','单位','效果']
            if (as.options[i][1] == '-') {
                //设置display'none'的对象 到'display'
                //当对象设置了display'none'将会阻碍参数的获取
                if (zZ(as.lpoolObj).css('display') == 'none') {
                    zZ(as.lpoolObj).css('display', 'block');
                    zZ(as.lpoolObj).attr('_jpool_dpser', '_jpool_dpser');
                }
                as.options[i][1] = parseFloat(zZ(as.lpoolObj).css(as.options[i][0]).toString().replace('px'));
                if (zZ(as.lpoolObj).attr('_jpool_dpser')) {
                    zZ(as.lpoolObj).css('display', 'none');
                    zZ(as.lpoolObj).removeAttr('_jpool_dpser');
                }
            }

            //开始值
            var startValue = parseFloat(options[i][1]),

            //结束值
                endValue = parseFloat(options[i][2]),

            //总值
                totalValue = endValue - startValue,

            //老算法 ： 总值 除以 总时间 得到 速度 ，现在的时间 减去 开始的时间 得到 已逝去的时间 ， 速度乘以已逝去的时间得到现在的位置，现在的位置加上初始位置得到结果
            //computedtestNum = ((totalValue / totalTime) * (parseInt(+new Date) - startTime));
                computedNum = 0;

            //新算法
            //懂数学就是牛，下辈子一定要学好数学！
            switch (options[i][4]) {
                case '':
                case '--':
                    computedNum = zZ.Tween.Linear((parseFloat(+new Date) - startTime), startValue, totalValue, totalTime);
                    break;
                case '-<':
                    computedNum = zZ.Tween.Quint.easeIn((parseFloat(+new Date) - startTime), startValue, totalValue, totalTime);
                    break;
                case '>-':
                    computedNum = zZ.Tween.Quint.easeOut((parseFloat(+new Date) - startTime), startValue, totalValue, totalTime);
                    break;
                case '<>':
                    computedNum = zZ.Tween.Quint.easeInOut((parseFloat(+new Date) - startTime), startValue, totalValue, totalTime);
                    break;
                case '~~':
                    computedNum = zZ.Tween.Bounce.easeOut((parseFloat(+new Date) - startTime), startValue, totalValue, totalTime);
                    break
            }


            computedNum = computedNum - startValue;

            //修复误差
            if (totalValue > 0) { if (computedNum > totalValue) { computedNum = totalValue } }
            else if (totalValue < 0) { if (computedNum < totalValue) { computedNum = totalValue } }

            //算出该参数当前所处值      
            var fValue = (startValue + computedNum).toFixed(3);

            //更改对象值
            if (options[i][0].indexOf('zNum') == -1) {
                zZ(as.lpoolObj).css(options[i][0], fValue + options[i][3]);
            } else {
                zZ(as.lpoolObj).attr(options[i][0].split('.')[1], fValue + options[i][3]);
            }
        }
        //此处执行‘运行时回调函数’
        as.runtimeCallback && as.runtimeCallback.apply(as.lpoolObj, arguments);
    }
};

//帧对象的获取方法
zZ.Zstatic.fxFrameFunction = function () {
    return setInterval(function () {
        for (var i = 0; i < zZ.Zstatic.intervalList.length; i++) {
            if (zZ.Zstatic.intervalList[i]) {

                if (!zZ.Zstatic.intervalList[i].lpoolObj) {
                    delete zZ.Zstatic.intervalList[i];
                    return;
                }

                if (zZ.Zstatic.intervalList[i].state == 'play') {
                    zZ.Zstatic.intervalList[i].action(zZ.Zstatic.frequencyTime, zZ.Zstatic.intervalList[i]);
                }

                if (zZ.Zstatic.intervalList[i].startTime != '-') {
                    //如果 开始时间+总时间 < 当前时间 便结束此动画
                    if (parseInt(zZ.Zstatic.intervalList[i].startTime) + parseInt(zZ.Zstatic.intervalList[i].TotalTime) <= parseInt(+new Date)) {
                        zZ(zZ.Zstatic.intervalList[i].lpoolObj).removeAttr('_jpool_animation_id');
                        if (zZ.Zstatic.intervalList[i].callBack) {
                            zZ.Zstatic.intervalList[i].callBack.apply(zZ.Zstatic.intervalList[i].lpoolObj, arguments);
                        }
                        delete zZ.Zstatic.intervalList[i];
                        //清除一下无效数组:2013-06-17
                        zZ.Zstatic.intervalList = zZ.fn.clearEmptyItem(zZ.Zstatic.intervalList);
                        return;
                    }
                }
            }
        }
    }, zZ.Zstatic.frequencyTime);
}

//系统的帧对象
zZ.Zstatic.fxFrame = zZ.Zstatic.fxFrameFunction();