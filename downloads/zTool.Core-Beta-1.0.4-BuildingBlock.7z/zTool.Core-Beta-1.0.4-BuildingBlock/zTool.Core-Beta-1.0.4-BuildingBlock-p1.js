﻿//////////////////////////////////////////////////////////////////////基本功能//////////////////////////////////////////////////////////////////



//==============================================================================================================================================
//*********************************************************第一部分，zTool基本,基本的zTool结构**************************************************
//该部分包含:
//1.基础的zTool.fn封装对象,zZ对象，_zTool对象
//2.html元素选择器，选择器提供基础的html元素筛选
//3.全局静态zZ.Zstatic json原型，原型中放置zTool内部使用的全局静态变量，以及全局静态方法
//4.数组操作的一些自定义方法
//5.去除前后空格的方法
//:2013-06-10
//==============================================================================================================================================


//对象操作器
//更新于2013-09-01
//更新内容：增加闭包，以避免代码作用域混乱
(function (window) {
    window.zTool = window.zZ = function (input) {
        return new _zTool(input);
    };
    //建立主函数
    window._zTool = function (inputObj) {
        //输入的字符串/对象
        this.InputObj = inputObj;

        //判断用户是否是想创建一个元素对象                                                                    //判断一对完整的闭合标签，或者一个非闭合标签
        if (typeof (inputObj) == 'string' && new RegExp('^<([a-zA-Z]+)[ ]*([ ]+[a-zA-Z0-9]+=.+)*>.*</[a-zA-Z]+>$|^<([a-zA-Z]*)[ ]*([ ]+[a-zA-Z0-9]{1,}=.+)*/>$').test(inputObj)) {
            if (!this.createElement) { alert('zTool.Core：Undefined function of "zT.createElement" ,\n if you need create elements width zTool.Core, \n please add "part 2" of zebra tool to your zTool.Core-Beta-x.x.x.js.') }
            this.lObj = this.createElement(inputObj);
        } else {
            //进入简单选择器,开始查找元素，并存入元素数组
            this.lObj = this.findElement(inputObj);
        }
    }

    //设置主函数的属性/方法
    window.zZ.fn =
    window._zTool.prototype =
    window.zT =
    {//为方便调试记录选择器分析的文本 ：2013-02-26
        InputObj: null
    , //查找元素
        findElement: function (selectObj) {
            var elements = [];
            //一级选择器
            if (selectObj) {
                switch (typeof (selectObj)) {
                    case 'string': //如果是STRING说明传入的是对象ID 或者某种选择器
                        elements = this.stringSeleter(selectObj);
                        break;
                    case 'object': //如果是object说明传入的是个对象
                        elements.push(selectObj);
                        break;
                }
            }
            return elements;
        }
    ,   //文本选择分析器
        stringSeleter: function (string, inputNode) {
            var elements = [];
            if (!inputNode) { inputNode = document.documentElement.childNodes; }
            //通过样式选择
            if (new RegExp('^[\.]').test(string)) {
                string = string.replace('.', '');
                var allElements = document.body;
                elements = zZ.Zstatic.selector.selectCss(inputNode, string);
                return elements;
            }

            //通过ID选择
            if (new RegExp('^[\#]').test(string)) {
                string = string.replace('#', '');
                elements = zZ.Zstatic.selector.selectPrototype(inputNode, "id=" + string);
                return elements;
            }

            //通过tagName
            if (new RegExp('^<.{1,}>').test(string)) {
                string = string.replace('<', '').replace('>', '');
                elements = zZ.Zstatic.selector.selectTagName(inputNode, string);
                return elements;
            }

            //通过属性获取对象数组selectPrototype
            if (new RegExp('(^[\:])([a-zA-Z0-9]{1,}=.{1,}$)').test(string)) {
                string = string.replace(':', '');
                elements = zZ.Zstatic.selector.selectPrototype(inputNode, string);
                return elements;
            }

            //默认通过ID选择
            elements.push(document.getElementById(string));
            return elements;
        }
    ,   //通过某种条件，在已经找到的对象中继续查找(可以使用一级选择器所有的语法)
        find: function (input) {
            //通过属性获取对象数组selectPrototype
            this.lObj = this.stringSeleter(input, this.lObj);
            return this;
        }
    ,   //返回所有找到的对象(对象数组)
        Elements: function () {
            if (this.lObj.length == 0) { return undefined };
            return this.lObj;
        }
    ,    //返回找到的对象（单个对象）
        E: function () {
            if (this.lObj.length == 0) { return undefined };
            return this.lObj[0];
        }
    ,   //删除某数组里的某值的项目
        delArr: function (arr, value) {
            var rArr = [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] != value) {
                    rArr.push(arr[i]);
                }
            }
            return rArr;
        }
    ,   //清除数组中不存在的元素 :  2013-02-26
        clearEmptyItem: function (arr) {
            var rArr = [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i]) {
                    rArr.push(arr[i]);
                }
            }
            return rArr;
        }
    ,   //将一组数组中的栈压倒另一个数组中去
        joinArr: function (inArr, pArr) {
            for (var i = 0; i < pArr.length; i++) {
                inArr.push(pArr[i]);
            }
            return inArr;
        }
    ,   //去除前后空格
        trim: function (str) {
            if (str == '') { return str }
            return str.toString().trim();
        }
    };

    //全局静态方法/变量
    window.zZ.Zstatic = {
        clCss: null,
        //需要进行动画计时的对象列表{'lpoolID':xxxxxx,'lpoolObj':xxxxxx,'startTime':xxxxxx,'TotalTime':xxxxxx,'options':xxxxxx,'state':play/stop,'action':xxxxxx,'callBack':xxxxxx}
        intervalList: [],
        //帧渲染频率
        frequencyTime: 1,
        //动作
        frameAction: null,
        //动画计时器
        fxFrame: null,
        //动画计时器的方法
        fxFrameFunction: null,
        //选择器选择组件
        selector: null,
        //{zTool_Delay_id:'',timer:xxxx}
        delayTimerArr: []
    }

    //选择器
    window.zZ.Zstatic.selector = {
        //CSS选择器
        selectCss: function (nodes, string) {
            var elements = [];
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i].getAttribute) {
                    if (nodes[i].getAttribute('className') || nodes[i].getAttribute('class')) {
                        if (nodes[i].getAttribute('className')) {
                            if (zZ.fn.trim(nodes[i].getAttribute('className')) == string) {
                                elements.push(nodes[i]);
                            }
                        } else {
                            if (zZ.fn.trim(nodes[i].getAttribute('class')) == string) {
                                elements.push(nodes[i]);
                            }
                        }
                    }
                }
                if (nodes[i].childNodes) {
                    elements = zZ.fn.joinArr(elements, zZ.Zstatic.selector.selectCss(nodes[i].childNodes, string));
                }
            }
            return elements;
        }
,
        //属性选择器
        selectPrototype: function (nodes, string) {
            var elements = [],
        Pname = string.split('=')[0],
        Pvalue = string.split('=')[1];
            for (var i = 0; i < nodes.length; i++) {
                var added = false;
                if (nodes[i][Pname]) {
                    if (nodes[i][Pname].toString().trim() == Pvalue.trim()) {
                        elements.push(nodes[i]);
                        added = true;
                    }
                }

                if (!added) {
                    if (nodes[i].attributes) {
                        if (nodes[i].attributes[Pname]) {
                            if (nodes[i].attributes[Pname].value == Pvalue) {
                                elements.push(nodes[i]);
                            }
                        }
                    }
                }

                if (nodes[i].childNodes) {
                    elements = zZ.fn.joinArr(elements, zZ.Zstatic.selector.selectPrototype(nodes[i].childNodes, string));
                }
            }
            return elements;
        }
,
        //tagName选择器
        selectTagName: function (nodes, string) {
            var elements = [];
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i].tagName) {
                    if (nodes[i].tagName.toLowerCase() == string.toLowerCase()) {
                        elements.push(nodes[i]);
                    } else if (string == '*') { elements.push(nodes[i]); }
                }

                if (nodes[i].childNodes) {
                    elements = zZ.fn.joinArr(elements, zZ.Zstatic.selector.selectTagName(nodes[i].childNodes, string));
                }
            }
            return elements;
        }
    }

    //TRIM方法
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g, "");
    }

    //此段代码并非本人所写
    //此代码来源于http://www.json.org/js.html
    //若有兴趣可进入以上链接研读该代码
    //
    //此代码功能为:
    //在ie6/7下可使用JSON对象
    //增加JSON.stringify()方法
    //增加JSON.parse()方法
    //
    //若您认为此代码无用，可将其剔除，解除在ie6/7下对JSON对象的支持
    //更新于2013-09-25
    "object" != typeof JSON && (JSON = {}), function () { "use strict"; function f(a) { return 10 > a ? "0" + a : a } function quote(a) { return escapable.lastIndex = 0, escapable.test(a) ? '"' + a.replace(escapable, function (a) { var b = meta[a]; return "string" == typeof b ? b : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) + '"' : '"' + a + '"' } function str(a, b) { var c, d, e, f, h, g = gap, i = b[a]; switch (i && "object" == typeof i && "function" == typeof i.toJSON && (i = i.toJSON(a)), "function" == typeof rep && (i = rep.call(b, a, i)), typeof i) { case "string": return quote(i); case "number": return isFinite(i) ? String(i) : "null"; case "boolean": case "null": return String(i); case "object": if (!i) return "null"; if (gap += indent, h = [], "[object Array]" === Object.prototype.toString.apply(i)) { for (f = i.length, c = 0; f > c; c += 1) h[c] = str(c, i) || "null"; return e = 0 === h.length ? "[]" : gap ? "[\n" + gap + h.join(",\n" + gap) + "\n" + g + "]" : "[" + h.join(",") + "]", gap = g, e } if (rep && "object" == typeof rep) for (f = rep.length, c = 0; f > c; c += 1) "string" == typeof rep[c] && (d = rep[c], e = str(d, i), e && h.push(quote(d) + (gap ? ": " : ":") + e)); else for (d in i) Object.prototype.hasOwnProperty.call(i, d) && (e = str(d, i), e && h.push(quote(d) + (gap ? ": " : ":") + e)); return e = 0 === h.length ? "{}" : gap ? "{\n" + gap + h.join(",\n" + gap) + "\n" + g + "}" : "{" + h.join(",") + "}", gap = g, e } } "function" != typeof Date.prototype.toJSON && (Date.prototype.toJSON = function () { return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null }, String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function () { return this.valueOf() }); var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = { "\b": "\\b", "	": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\" }, rep; "function" != typeof JSON.stringify && (JSON.stringify = function (a, b, c) { var d; if (gap = "", indent = "", "number" == typeof c) for (d = 0; c > d; d += 1) indent += " "; else "string" == typeof c && (indent = c); if (rep = b, b && "function" != typeof b && ("object" != typeof b || "number" != typeof b.length)) throw new Error("JSON.stringify"); return str("", { "": a }) }), "function" != typeof JSON.parse && (JSON.parse = function (text, reviver) { function walk(a, b) { var c, d, e = a[b]; if (e && "object" == typeof e) for (c in e) Object.prototype.hasOwnProperty.call(e, c) && (d = walk(e, c), void 0 !== d ? e[c] = d : delete e[c]); return reviver.call(a, b, e) } var j; if (text = String(text), cx.lastIndex = 0, cx.test(text) && (text = text.replace(cx, function (a) { return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) })), /^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) return j = eval("(" + text + ")"), "function" == typeof reviver ? walk({ "": j }, "") : j; throw new SyntaxError("JSON.parse") }) } ();

})(window);