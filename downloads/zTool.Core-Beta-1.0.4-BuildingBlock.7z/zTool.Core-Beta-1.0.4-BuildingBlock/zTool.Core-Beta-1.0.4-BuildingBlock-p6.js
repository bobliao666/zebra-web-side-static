﻿//==============================================================================================================================================
//*********************************************************第二部分，Ajax通讯*******************************************************************
//该部分实现Ajax通讯
//1.ajax发送方法 
//2.ajax获取数据方法
//3.AJAX方法 参数
//:2013-06-10
//==============================================================================================================================================

//ajax发送方法
zT.post = function (url, ajaxAction, Parameter, successCall, failedCall) {
    if (!successCall) { successCall = function () { }; }
    if (!failedCall) { failedCall = function () { }; }
    zZ.ajax(url + ajaxAction + "?refNumberAjax=" + Math.random().toString().replace('.', ''),
       { requestType: 'POST',
           asynch: true,
           sendData: Parameter,
           type: "text",
           success: function (data) {
               successCall(data);
           },
           failed: function (request, status) {
               failedCall(request, status);
           }
       });
}
//ajax获取数据方法
zT.get = function (url, ajaxAction, Parameter, successCall, failedCall) {
    if (!successCall) { successCall = function () { }; }
    if (!failedCall) { failedCall = function () { }; }
    zZ.ajax(url + ajaxAction + "?refNumberAjax=" + Math.random().toString().replace('.', ''),
       { requestType: 'GET',
           asynch: true,
           sendData: Parameter,
           type: "text",
           success: function (data) {
               successCall(data);
           },
           failed: function (request, status) {
               failedCall(request, status);
           }
       });
}


//AJAX方法 传入url，options：{requestType:GET/POST,asynch:true/false,sendData:xxxxxx,type:"text/json",success:function,failed:function}
zZ.ajax = function (url, options) {
    //定义Ajax通讯容器
    var request = false;

    var setUpAjax = function () {
        try {//应对普通浏览器
            request = new XMLHttpRequest();
        } catch (trymicrosoft) {
            try {//应对微软的XMLHTTPREQUEST4.0 : 2013-08-22
                request = new ActiveXObject("Msxml2.XMLHTTP.4.0");
            } catch (othermicrosoft) {
                try {//应对微软的XMLHTTPREQUEST
                    request = new ActiveXObject("Msxml2.XMLHTTP");
                } catch (othermicrosoft) {
                    try {//应对更老的微软XMLHTTPREQUEST
                        request = new ActiveXObject("Microsoft.XMLHTTP");
                    } catch (failed) {//还没有就直接提示用户您浏览器实在太老了，丢不起这脸
                        request = false;
                    }
                }
            }
        }
        if (!request) {
            alert("Error! Your borwser version is too old, please upgrade your borwser!\n您的浏览器可能版本过低，请升级系统后再继续使用本网页！");
        }
    }

    //回调函数
    //在里面判断请求状态来触发回调函数
    //2013-08-22
    var callBackFunc = function () {
        //成功接受到响应
        if (request.readyState == 4) {
            if (request.status == 200) {
                //成功之后执行成功的回调函数
                options.success(request.responseText);
            }
            else {
                //失败的回调函数
                options.failed(request, request.status);
            }
        }
    }

    //初始化AJAX
    setUpAjax();

    //接收配置
    var options = options || { requestType: 'GET', asynch: true, sendData: null, type: "Text", success: function () { }, failed: function () { } }

    //如果用户注明传送类型为json,那么就将其json格式的传送值转换为string格式
    //2013-09-25
    if (options.type == "json") {
        options.sendData = JSON.stringify(options.sendData);
    }

    //打开链接
    request.open(options.requestType, encodeURI(url), options.asynch);

    //设置回调函数
    request.onreadystatechange = callBackFunc;

    //则需要设置http头以正确使用send方法,否则请求将会出现一些屎尿未及的错误
    //以form表单方式提交
    //2013-08-22
    request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    //发送数据
    request.send(options.sendData);
}