﻿//==============================================================================================================================================
//*********************************************************第二部分，HTML对象操作***************************************************************
//该部分主要围绕操作HTML节点
//该部分包含:
//1.使用zZ(input)构造一个或多个元素
//1.获取子节点
//2.获取父节点
//3.设置innerHTML值
//4.在某节点里增加一个元素
//5.清空某元素下的所有子级节点
//6.在某节点之前插入
//7.在某节点之后插入：2013-06-11
//8.用某个元素去替换某个元素
//9.克隆对象，使之不产生任何指针引用
//:2013-06-10
//==============================================================================================================================================
//获取子节点
zT.childen = function () {
    var elements = [];
    for (var i = 0; i < this.lObj[0].childNodes.length; i++) {
        if (this.lObj[0].childNodes[i].tagName) {
            elements.push(this.lObj[0].childNodes[i]);
        }
    }
    this.lObj = elements;
    return this;
} //获取父节点
zT.parent = function () {
    var a = [];
    a.push(this.lObj[0].parentNode);
    this.lObj = a;
    return this;
} //设置innerHTML值
zT.html = function (v) {
    if (this.lObj.length == 0) { return undefined };
    if (!v) { return this.lObj[0].innerHTML; }
    for (var j = 0; j < this.lObj.length; j++) {
        this.lObj[j].innerHTML = v;
    }
    return this;
}  //创建元素
zT.createElement = function (input) {
    var adder = document.createElement('div'), sub = "", nodes = null,
             identity = 'data-zTool-appendNode-' + (+new Date / Math.random()).toString().replace('.', '');

    //将输入的HTML去除前后空格
    input = zZ.fn.trim(input);
    //判断之中是否有tbody,thead,tr,tfoot 有的话便创建table 而不是div
    sub = 0
    if (new RegExp('^[ ]{0,}<(td|th|tr|thead|tbody|tfoot)').test(input)) {
        var tInput = input;
        input = "<table>" + input + "</table>";
        if (new RegExp('^[ ]{0,}<(tr)[ ]*([ ]+[a-zA-Z0-9]+=.+)*>').test(tInput)) {
            sub = 2;
        }
        else if (new RegExp('^[ ]{0,}<(td|th)[ ]*([ ]+[a-zA-Z0-9]+=.+)*>').test(tInput)) {
            sub = 3;
        }
        else {
            sub = 1;
        }
    }
    //设置一个临时容器，将要append的元素放进去先
    adder.setAttribute('id', identity);
    adder.innerHTML = input;
    document.body.appendChild(adder);

    //让浏览器去构造用户输入的元素，我们在这里只需要获得浏览器已经构造好的元素
    nodes = document.getElementById(identity);

    //一旦检测到类似table这样的元素的时候，
    //会启动一个类似于计数器的东西，
    //它将记录我们真正要获得的元素在第几个嵌套里
    var thatObj = document.getElementById(identity);
    for (var i = 0; i < sub; i++) {
        thatObj = thatObj.childNodes[0];
    }
    nodes = thatObj.childNodes;

    //再将我们要添加的内容复制到内存中去
    var nodeArr = [];
    for (var i = 0; i < nodes.length; i++) {
        nodeArr.push(zZ.fn.clone(nodes[i]));
    }
    //将临时容器删除,消灭作案证据(偷笑)
    document.body.removeChild(document.getElementById(identity));
    return nodeArr;
}  //在某节点里增加一个元素
zT.append = function (input) {
    if (this.lObj.length == 0) { return undefined }
    for (var j = 0; j < this.lObj.length; j++) {
        if (typeof (input) == 'string') {
            var nodeArr = this.createElement(input);
            for (var i = 0; i < nodeArr.length; i++) {
                this.lObj[j].appendChild(nodeArr[i]);
            }
        } else {
            this.lObj[j].appendChild(input);
        }
    }
    return this;
} //向某节点插入
zT.appendTo = function (input) {
    if (this.lObj.length == 0) { return undefined }
    var appNode = zTool(input).Elements();
    var cNodes = [];
    for (var i = 0; i < appNode.length; i++) {
        for (var j = 0; j < this.lObj.length; j++) {
            var tNode = zT.clone(this.lObj[j]);
            appNode[i].appendChild(tNode);
            cNodes.push(tNode);
        }
    }
    this.lObj = cNodes;
    return this;
} //清空某元素下的所有子级节点
zT.empty = function () {
    if (this.lObj.length == 0) { return undefined }
    for (var j = 0; j < this.lObj.length; j++) {
        if (this.lObj[j].childNodes.length != 0) {
            this.lObj[j].removeChild(this.lObj[j].childNodes[0]);
            if (this.lObj[j].childNodes.length != 0) {
                zZ(this.lObj[j]).empty();
            }
        }
    }
    return this;
} //删除一个元素
zT.remove = function () {
    if (this.lObj.length == 0) { return undefined }
    for (var j = 0; j < this.lObj.length; j++) {
        try { this.lObj[j].parentNode.removeChild(this.lObj[j]); } catch (e) { };
    }
}  //在某节点之前插入
zT.insertBefore = function (input) {
    if (this.lObj.length == 0) { return undefined }
    for (var j = 0; j < this.lObj.length; j++) {
        if (typeof (input) == 'string') {
            var adder = document.createElement('div'),
                identity = 'zTool_appendNode_' + (+new Date / Math.random()).toString().replace('.', '');
            adder.setAttribute('id', identity);
            document.body.appendChild(adder);
            document.getElementById(identity).innerHTML = input;
            var nodes = document.getElementById(identity).childNodes;

            for (var i = 0; i < nodes.length; i++) {
                var nodeNow = nodes[i];
                this.lObj[j].parentNode.insertBefore(nodeNow, this.lObj[j]); //修正BUG：2013-06-11
            }

            document.body.removeChild(document.getElementById(identity));
        } else {
            this.lObj[j].parentNode.insertBefore(input, this.lObj[j]); //修正BUG：2013-06-11
        }
    }
    return this;
} //在某节点之后插入：2013-06-11
zT.insertBehind = function (input) {
    if (this.lObj.length == 0) { return undefined }
    for (var j = 0; j < this.lObj.length; j++) {
        var parent = this.lObj[j].parentNode;
        var appNode = null;
        var appendStyle = "append";
        if (parent.childNodes.length > 1) {
            appendStyle = "insertBefore";
            for (var childs = 0; childs < parent.childNodes.length; childs++) {
                if (parent.childNodes[childs] == this.lObj[j]) {
                    if (!parent.childNodes[childs + 1]) {
                        appendStyle = "append";
                        continue;
                    }
                    appNode = parent.childNodes[childs + 1];
                    continue;
                }
            }
        }

        if (appendStyle == "append") {
            zTool(parent).append(input);
        } else {
            zTool(appNode).insertBefore(input);
        }
    }
    return this;
} //用某个元素去替换某个元素/该方法有效果，
//但是没有达到预期的替换效果,需要完善:2013-06-10
//效果已经达成，问题修复！ :2013-06-10
zT.replaceWith = function (htmlDocument) {
    if (this.lObj.length == 0) { return undefined }
    for (var j = 0; j < this.lObj.length; j++) {
        var rId = "replaceWith_Sine_" + (+new Date / Math.random()).toString().replace('.', '');
        zTool(this.lObj[j]).insertBefore("<a id='" + rId + "'></a>");
        zTool(this.lObj[j]).remove();
        zTool("#" + rId).insertBefore(htmlDocument);
        zTool("#" + rId).remove();
    }
}    //克隆对象，使之不产生任何指针或引用
zT.clone = function (Object) {
    if (Object) {
        return Object.cloneNode(true);
    } else {
        return this.lObj[0].cloneNode(true);
    }
}