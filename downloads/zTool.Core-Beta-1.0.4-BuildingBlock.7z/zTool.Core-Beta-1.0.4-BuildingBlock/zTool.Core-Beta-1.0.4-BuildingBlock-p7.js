﻿//==============================================================================================================================================
//*********************************************************第三部分，其他功能*******************************************************************
//包含延时执行函数
//:2013-06-10
//==============================================================================================================================================
//延时方法，延迟执行函数
zT.delay = function (time, callBack) {
    //构建委托
    var func = function (callBack, thisObj) {
        this.callBack = callBack;
        this.thisObj = thisObj;
        this.applyCallback = function () {
            zTool(thisObj).stopDelay();
            callBack.apply(thisObj, arguments);
        };
    }
    //创建委托
    var Func = new func(callBack, this.lObj[0]);
    //创建id 
    var zToolDelayId = (+new Date / Math.random()).toString().replace('.', '');
    //执行委托
    var timer = setTimeout(function () { Func.applyCallback() }, time);

    zTool(this.lObj[0]).attr('zTool_Delay_id', zToolDelayId);

    //{zTool_Delay_id:'',timer:xxxx} 将延时操作压入操作栈
    zZ.Zstatic.delayTimerArr.push({ 'zTool_Delay_id': zToolDelayId, 'timer': timer });
}
//停止某对象上的延时
zT.stopDelay = function () {
    if (zTool(this.lObj[0]).attr('zTool_Delay_id')) {
        var index = null;
        for (var i = 0; i < zZ.Zstatic.delayTimerArr.length; i++) {
            if (zZ.Zstatic.delayTimerArr[i].zTool_Delay_id == zTool(this.lObj[0]).attr('zTool_Delay_id')) {
                //注销计时器
                clearInterval(zZ.Zstatic.delayTimerArr[i].timer);
                //ID取消
                zTool(this.lObj[0]).removeAttr('zTool_Delay_id');

                index = i;
                break;
            }
        }
        zZ.Zstatic.delayTimerArr = zZ.fn.delArr(zZ.Zstatic.delayTimerArr, zZ.Zstatic.delayTimerArr[index]);
    }
    return this;
}